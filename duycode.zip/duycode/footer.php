<footer id="footer">
  <?php wp_footer(); ?>
  <div class="container">
    <span> DuyCode &copy; 2019. Website được phát triển bởi công ty TNHH Medihome - 0986.021.190 </span>
  </div>
</footer>
</body>

</html>